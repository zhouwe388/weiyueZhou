 package linalg;

/*** A class that represents a two dimensional real-valued (double) matrix
 *   and supports various matrix computations required in linear algebra.
 *   
 *   Class and method comments are in JavaDoc: https://en.wikipedia.org/wiki/Javadoc
 * 
 * @author ssanner@mie.utoronto.ca, <weiyue.zhou@mail.utoronto.ca>
 *
 */
public class Matrix {

	private int _nRows; // Number of rows in this matrix; nomenclature: _ for data member, n for integer
	private int _nCols; // Number of columns in this matrix; nomenclature: _ for data member, n for integer
	// TODO: add your own data member to represent the matrix content
	//       you could use a 2D array, or an array of Vectors (e.g., for each row)
        private double [][]_n2darray; //created a 2d array
        
	
	/** Allocates a new matrix of the given row and column dimensions
	 * 
	 * @param rows: initializes the number of rows in this matrix
	 * @param cols: initializes the number of columns in this matrix
	 * @throws LinAlgException if either rows or cols is <= 0
	 */
	public Matrix(int rows, int cols) throws LinAlgException {
		// TODO: hint: see the corresponding Vector constructor
                if ( cols <= 0)
			throw new LinAlgException("rows or cols can't be less or equal to zero");
                else if (rows <= 0)
                    throw new LinAlgException ("rows or cols can't be less or equal to zero");
		_nRows = rows; //initializing values
		_nCols = cols;
                _n2darray= new double [rows][cols];
                
                        
	}
	
	/** Copy constructor: makes a new copy of an existing Matrix m
	 *                    (note: this explicitly allocates new memory and copies over content)
	 * 
	 * @param m the matrix that is about to be copied to this matrix 
	 */
	public Matrix(Matrix m) {
		// TODO: hint: see the corresponding Vector "copy constructor" for an example
                _nRows = m._nRows; //making copy of existing m
                _nCols = m._nCols;
		_n2darray = new double[_nRows][_nCols];
		for (int index = 0; index < _nRows; index++){
                    for (int index1 = 0; index1 < _nCols; index1++){
			_n2darray[index][index1] = m._n2darray[index][index1];
	            }
                }
        }
	/** Constructs a String representation of this Matrix
	 * 
	 */
	public String toString() {
		// TODO: hint: see Vector.toString() for an example
                StringBuilder sb = new StringBuilder();//only stringbuilder has the append method, not string
		
		for (int i = 0; i < _nRows; i++){
                    sb.append("[ "); //add "[" for the beginning of each row
                
                    for (int j=0; j < _nCols; j++){
                
			sb.append(String.format(" %6.3f ", _n2darray[i][j]));  //add values into each row
		
                    }
                sb.append(" ]\n"); //add "]" at the end of each row
                }
                
		return sb.toString();
		
	}

	/** Tests whether another Object o (most often a matrix) is a equal to *this*
	 *  (i.e., are the dimensions the same and all elements equal each other?)
	 * 
	 * @param o the object to compare with this matrix
	 */
	public boolean equals(Object o) {
		// TODO: hint: see Vector.equals(), you can also use Vector.equals() for checking equality 
		//             of row vectors if you store your matrix as an array of Vectors for rows
		
		// TODO: this should not always return false!
                if (o instanceof Matrix) {
			Matrix newmax = (Matrix)o; // This is called a cast (or downcast) since o is ordinary an object, casted into a vector
                       if ((_nCols != newmax._nCols) || (_nRows != newmax._nRows)){
				return false; } //mismatch of number of rows&cols
			for (int i = 0; i < _nRows; i++){
                            for (int j = 0; j < _nCols; j++){
				if (_n2darray[i][j] != newmax._n2darray[i][j])
					return false; //mismatch values 
                            }
                         }return true; // Everything matched... objects are equal!
		}
                else// if we get here "(o instanceof Vector)" was false
			return false; // Two objects cannot be equal if they don't have the same class type
                
		
	}
	
	/** Return the number of rows in this matrix
	 *   
	 * @return the number of rows in this matrix
	 */
	public int getNumRows() {
		// TODO (this should not return -1!)
                 
		return _nRows;
	}

	/** Return the number of columns in this matrix
	 *   
	 * @return the number of columns in this matrix
	 */
	public int getNumCols() {
		// TODO (this should not return -1!)
		return _nCols;
	}

	/** Return the scalar value at the given row and column of the matrix
	 * 
	 * @param row: the row location of the scalar value
	 * @param col: the column location of the scalar value
	 * @return the scalar value at the given location of row and column
	 * @throws LinAlgException if row or col indices are out of bounds
	 */
	public double get(int row, int col) throws LinAlgException {
		// TODO (this should not return -1!)
                if ((row > _nRows) || (col > _nCols)){
                    throw new LinAlgException("row/col are out of bounds");
                }
                else{
                    return _n2darray[row][col]; //return value in the specific row & col.
                }
		
	}
	
	/** Return the Vector of numbers corresponding to the provided row index
	 * 
	 * @param row: the row of matrix values that need to be returned
	 * @return: the new vector that contains all the values in that row
	 * @throws LinAlgException if row is out of bounds
	 */
	public Vector getRow(int row) throws LinAlgException {
		// TODO (this should not return null!)
                if (row> _nRows){
                    throw new LinAlgException("row is out of bounds");
                }
                else{
                    Vector newvec = new Vector(_nCols); //create a new vector with same dimension as the number of columns, empty(filled with zero)
                    for (int i =0; i<_nCols; i++){
                        
                     newvec.set(i,_n2darray[row][i]);//using the set method in vector to set value, the value comes from the specific row of the 2d array
                         
                     }
                    
                    return newvec ;
                }
                   
	}

	/** Set the row and col of this matrix to the provided val
	 * 
	 * @param row: the row location of the value that is need to be stored
	 * @param col: the column location of the value that is need to be stored
	 * @param val: the value that is need to be store in the matrix given the row and column number
	 * @throws LinAlgException if row or col indices are out of bounds
	 */
	public void set(int row, int col, double val) throws LinAlgException {
		// TODO
               if ((row > _nRows) || (col > _nCols)){
                    throw new LinAlgException("row/col are out of bounds");
               }
               else{
                   _n2darray[row][col]= val;
               }
                  
	}
	
	/** Return a new Matrix that is the transpose of *this*, i.e., if "transpose"
	 *  is the transpose of Matrix m then for all row, col: transpose[row,col] = m[col,row]
	 *  (should not modify *this*)
	 * 
	 * @return the new transposed matrix 
	 * @throws LinAlgException
	 */
	public Matrix transpose() throws LinAlgException {
		Matrix transpose = new Matrix(_nCols, _nRows);
		for (int row = 0; row < _nRows; row++) {
			for (int col = 0; col < _nCols; col++) {
				transpose.set(col, row, get(row,col));
			}
		}
		return transpose;
	}

	/** Return a new Matrix that is the square identity matrix (1's on diagonal, 0's elsewhere) 
	 *  with the number of rows, cols given by size.  E.g., if size = 3 then the returned matrix
	 *  would be the following:
	 *  
	 *  [ 1 0 0 ]
	 *  [ 0 1 0 ]
	 *  [ 0 0 1 ]
	 * 
	 * @param size: the matrix square's side length
	 * @return the new matrix that is the square identity matrix
	 * @throws LinAlgException if the size is <= 0
	 */
	public static Matrix GetIdentity(int size) throws LinAlgException {
		// TODO: this should not return null!
                 if (size <=0){
                    throw new LinAlgException("size can't be <=0");}
                 else{
                     Matrix newmax= new Matrix(size,size); //create a square matrix (all with value of 0)
                     for (int i=0; i<size; i++){
                         newmax.set(i,i,1); //using the matrix set method to set the value of 1 diagionally
                         
                         
                     }
                 
		return newmax;
	}}
	
	/** Returns the Matrix result of multiplying Matrix m1 and m2
	 *  (look up the definition of matrix multiply if you don't remember it)
	 * 
	 * @param m1: matrix number 1 about to be multiplied
	 * @param m2: matrix number 2 about to be multiplied
	 * @return the result of multiplying matrix m1 and m2
	 * @throws LinAlgException if m1 columns do not match the size of m2 rows
	 */
	public static Matrix Multiply(Matrix m1, Matrix m2) throws LinAlgException {
		// TODO: this should not return null!
                
                double sumofe= 0;
                if (m1._nCols != m2._nRows){
                    throw new LinAlgException("m1 columns do not match the size of m2 rows");
                }
                else{
                   Matrix newmat= new Matrix(m1._nRows, m2._nCols); //made new matrix size right
                   for (int i =0; i<m1._nRows; i++){ //i represents row
                       for (int j=0; j<m2._nCols; j++){ //j represents col
                           for (int k=0; k<m2._nCols; k++){ // k with the assistant of i or j is representing the value that is being added up .
                              sumofe=sumofe+(m1._n2darray[i][k]*m2._n2darray[k][j]); 
                              newmat.set(i, j, sumofe);
                              
                              
                           }
                           sumofe=0;
                         
                           
                   }}
                
		return newmat;
                }
	}
		
	/** Returns the Vector result of multiplying Matrix m by Vector v (assuming v is a column vector)
	 * 
	 * @param m: the matrix that is about to be multiplied with a vector
	 * @param v: the vector that is about to be multiplied with the matrix
	 * @return the vector result
	 * @throws LinAlgException if m columns do match the size of v
	 */
	public static Vector Multiply(Matrix m, Vector v) throws LinAlgException {
		// TODO: this should not return null!
                double sumofe = 0;//holding values for addtion of values
                Vector newvec = new Vector(v.getDim()); //getdim=dim of the vector
                if (m._nCols != v.getDim()){
                    throw new LinAlgException("m columns don't match the size of v");
                }
                else{
                    
                
                for (int i =0; i<m._nCols; i++){ 
                       for (int j=0; j<v.getDim(); j++){ //j represents the index in the vector, has to be less than the vector's dimension.
                           sumofe=sumofe+(m._n2darray[i][j]*v.get(j));
                           newvec.set(i,sumofe);
                           
                           
                       }
                    sumofe=0;        
                }
		return newvec;
	}


        }
}