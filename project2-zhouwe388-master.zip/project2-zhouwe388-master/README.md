# MIE250 Project 2

Please see the assignment description posted on Blackboard for instructions.
