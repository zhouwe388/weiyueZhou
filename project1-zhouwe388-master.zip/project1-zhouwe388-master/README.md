# MIE250 Project1

Please see the assignment description posted on Blackboard for instructions.
