// Your solution to MIE250 Project 1 goes here

import java.io.*;

/**
 *
 * @author zhouwe38
 */
public class FizzBuzz {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[]args) throws NumberFormatException, IOException{
        
        int fizz, buzz, start, end;
                    BufferedReader inputt1;
        inputt1 = new BufferedReader( new InputStreamReader(System.in));
        
        while(true) {
            System.out.print("   JAVA FIZZBUZZ PROGRAM\n");

        
        
        System.out.print("Enter Fizz number: ");
        fizz= Integer.parseInt(inputt1.readLine());
        if (fizz == 0)
            { 
                
            System.out.print("\nThe end.\n");
                    System.exit(0);}
        while (fizz < 0){
            System.out.print("ERROR: Negative numbers are not allowed! Try again: ");
            fizz= Integer.parseInt(inputt1.readLine());
            if (fizz == 0)
            { 
                
            System.out.print("\nThe end.\n");
                    System.exit(0);}

        }

        
                            
        System.out.print("Enter Buzz number: ");
        buzz= Integer.parseInt(inputt1.readLine());
            
        
        if (buzz == 0)
            { 
                
            System.out.print("\nThe end.\n");
                    System.exit(0);}
        while (buzz < 0){
            System.out.print("ERROR: Negative numbers are not allowed! Try again: ");
            buzz= Integer.parseInt(inputt1.readLine());
            if (buzz == 0)
            { 
                
            System.out.print("\nThe end.\n");
                    System.exit(0);}
        }
        
            
            
        
        System.out.print("Enter starting number: ");
        start= Integer.parseInt(inputt1.readLine());
        System.out.print("Enter ending number: ");
        end= Integer.parseInt(inputt1.readLine());
        
     
        
         
            while ( start > end ){ System.out.print("ERROR: Ending number cannot be less than starting number! Try again: ");
            end= Integer.parseInt(inputt1.readLine());
            
       
    } 
    System.out.print("\n");
     for(int i = start; i<= end; i=i+1){ 
         if (i%fizz==0 & i%buzz!=0){System.out.println(i + ". Fizz");}
         
         else if (i%buzz==0 & i%fizz!=0){System.out.println(i+ ". Buzz");}
         else if (i%buzz==0 & i%fizz==0){System.out.println(i+ ". FizzBuzz");}
         else if (i%buzz!=0 & i%fizz!=0){System.out.print(i +". " + i+ ""
                 + "\n");}
         
         
    
     } 
      System.out.print("\n");       
        
    }} }