# MIE250 Project 4

Please see the assignment description posted on Blackboard for instructions.
