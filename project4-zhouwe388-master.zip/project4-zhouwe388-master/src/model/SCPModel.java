/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.util.Collection;


import java.util.TreeSet;
import util.ElementSet;

/**
 *
 * @author zhouwe38
 */
public class SCPModel {
    private TreeSet<ElementSet> _SCPmodel; //ordered in ascending order
    private TreeSet<Integer> _elements; // all the elements ,not repeated
   
    
    public SCPModel(){
        this._SCPmodel= new TreeSet<>();
        this._elements= new TreeSet<>();
        
    }
    
    public void addSetToCover(int id, double cost, Collection<Integer> aset){
        
        
        
            
         _SCPmodel.add(new ElementSet(id,cost,aset));  
         
         _elements.addAll(aset);
        
       
    }
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Weighted SCP model:\n");
        sb.append("-----------------------\n");
        sb.append("Number of elements(n): " +_elements.size() +"\n");
        sb.append("Number of sets(m):"+ _SCPmodel.size()+ "\n");
        sb.append("Set details\n");
        sb.append("---------------------------------\n");
                
        for(ElementSet inset : _SCPmodel){//each set
            sb.append("\n");
            sb.append("Set ID:   ");
            sb.append(inset.getId());
            sb.append("   Cost:   ");
            sb.append(String.format("%.2f" ,inset.getcost()));
            sb.append("   Element IDs: ");
            sb.append(inset);//print elementset   
            
        }

       return sb.toString();
    }
    
    public TreeSet  getallelements(){
        TreeSet newset = new TreeSet();
         for( int inset: _elements){
           newset.add(inset);
     }
         return newset;
        
        
    }
    
    public double getnumelements(){
        return this.getallelements().size();
        
       
    }
    
    public double getnumsets(){
        return _SCPmodel.size();
    }
    
    public TreeSet<ElementSet> getElementcopy() {
        TreeSet newset= new TreeSet();
           for( ElementSet inset: _SCPmodel){
           newset.add(inset);
           
           }
        return newset;
    }
     
}




