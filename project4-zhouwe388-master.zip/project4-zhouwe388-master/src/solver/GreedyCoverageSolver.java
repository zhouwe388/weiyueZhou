/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solver;


import java.util.List;
import java.util.TreeSet;
import util.ElementSet;

/**
 *
 * @author zhouwe38
 */
public class GreedyCoverageSolver extends GreedySolver{
    
    public GreedyCoverageSolver(){
        _name= "Coverage";
        
    }
    
    
    public ElementSet nextBestSet(){
        
    
       int size=0;
       
       ElementSet bestset= new ElementSet(0,0.0, new TreeSet());
       
       
        for (ElementSet inset: _notwent){
            
            
           if((inset.countElementsCovered(_elementsNotCovered))> size){
               size=inset.countElementsCovered(_elementsNotCovered);
               bestset=inset;  
           }
           
        }
        //System.out.print(bestset);
                

                return bestset;
                
        
            
            
        }
       
    
    
}

