/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author zhouwe38
 */
public class ElementSet implements Comparable<ElementSet> {

    private int _setID;
    private double _cost;
    private TreeSet<Integer> _element;

    public ElementSet(int id, double cost, Collection<Integer> numofelem) {
        _setID = id;
        _cost = cost;
        _element = new TreeSet(numofelem);

    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        boolean exist = false;
        sb.append("[");
        for (int element : _element) {
            sb.append(element + ", ");
            exist = true;

        }

        if (exist) {
            sb.deleteCharAt(sb.length() - 1);
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("]");
        return sb.toString();
    }

    public int getId() {
        return _setID;
    }

    public double getcost() {
        return _cost;
    }

    public int compareTo(ElementSet o) {
        if (this._setID > o._setID) {
            return 1;
        } else if (this._setID < o._setID) {
            return -1;
        } else {
            return 0;
        }

    }

    public int getnumofelements() {
        return _element.size();
    }

    public TreeSet gettheset() {
        return _element;
    }

    public boolean containsElement(TreeSet<Integer> id) {
        ArrayList newb= new ArrayList();
        
        for (int x : _element) {
            for (int y : id) {

                newb.add((x == y));

            }
        }
        

        return newb.contains(true);
    }

    public int countElementsCovered(Set<Integer> elements_to_cover) {
//        ArrayList newlist= new ArrayList();
//        for(int i : _element){
//            for( int j: elements_to_cover){
//                if (i==j){
//                    newlist.add(i);
//                }
//            }
//        } _element.contains(elements_to_cover);
         int count =0;
         for(int i : elements_to_cover){
             if (_element.contains(i)){
             count=count+1;
         }
         
         }

        return count;
    }

    public Iterable<Integer> getelementIterable() {
        return _element;
    }
}
