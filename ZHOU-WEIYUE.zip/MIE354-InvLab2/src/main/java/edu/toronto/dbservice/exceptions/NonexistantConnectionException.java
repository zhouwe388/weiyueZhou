package edu.toronto.dbservice.exceptions;

public class NonexistantConnectionException extends Exception {

}
