package mie.ether_example;

import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.spec.ECGenParameterSpec;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.web3j.abi.datatypes.DynamicArray;
import org.web3j.abi.datatypes.generated.Bytes32;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.ECKeyPair;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.methods.request.Transaction;
import org.web3j.protocol.core.methods.response.EthCoinbase;
import org.web3j.protocol.core.methods.response.EthGetTransactionCount;
import org.web3j.protocol.core.methods.response.EthSendTransaction;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.protocol.http.HttpService;
import org.web3j.protocol.parity.Parity;
import org.web3j.protocol.parity.methods.response.PersonalUnlockAccount;
import org.web3j.tx.ClientTransactionManager;
import org.web3j.tx.Transfer;
import org.web3j.utils.Numeric;

import edu.toronto.dbservice.config.MIE354DBHelper;
import edu.toronto.dbservice.types.EmployeeVote;
import edu.toronto.dbservice.types.EtherAccount;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.bouncycastle.crypto.generators.ECKeyPairGenerator;
import org.bouncycastle.crypto.params.ECKeyGenerationParameters;

public class Vote implements JavaDelegate{
	
	Connection dbCon = null;

	public Vote() {
		dbCon = MIE354DBHelper.getDBConnection();
	}
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		// TODO: Get current employee account ID and save it into variable currentAccountID below
		Integer currentAccountID = (Integer) execution.getVariable("currentAccountID");
		
		// Next, we get the current vote from the form
		Integer selectedProposal = Integer.parseInt((String) execution.getVariable("aSelectedProposal"));
		
		// TODO: call the vote function on blockchain contract API to perform vote on behalf of the current employee for the selected proposal
		Web3j web3 = Web3j.build(new HttpService());
		String contractAddress = (String) execution.getVariable("contractAddress");
		HashMap<Integer, EtherAccount> accounts = (HashMap<Integer, EtherAccount>) execution.getVariable("accounts");
		Ballot employeeBallot = Ballot.load(contractAddress, web3, accounts.get(currentAccountID).getCredentials(), EtherUtils.GAS_PRICE, EtherUtils.GAS_LIMIT_CONTRACT_TX);
		
		Uint256 vote = new Uint256(BigInteger.valueOf(selectedProposal));
		TransactionReceipt voteReceipt = employeeBallot.vote(vote).get();
		EtherUtils.reportTransaction("Employee " + currentAccountID + " Voted for " + selectedProposal, voteReceipt);
		
		// TODO: Record vote in VoteRecord table in the database
		String query = "INSERT INTO VoteRecord (accountId, vote) VALUES (?, ?)";
		PreparedStatement preparedStmt = dbCon.prepareStatement(query);
		preparedStmt.setInt (1, currentAccountID); // field 1 & 2 is an int
		preparedStmt.setInt (2, selectedProposal); 
		preparedStmt.execute();

		
	}

}
