package mie.ether_example;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.rmi.registry.Registry;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Bytes32;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import java.util.Collection;
import edu.toronto.dbservice.types.EtherAccount;


//Run with parameters
public class InvLab2_Exercise1 extends LabBaseUnitTest {
	
	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/InvLab2_Ballot.bpmn";
	}
		
	private void startProcess() {	
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process_pool1");
	}
	
	private void fillBallotForm(String ballotCode) throws Exception {
		// form fields are filled using a map from field ids to values
		HashMap<String, String> formEntries = new HashMap<>();
		formEntries.put("aBallotCode", ballotCode);
		
		// get the user task (collect proposals)
		TaskService taskService = activitiContext.getTaskService();
		Task proposalsTask = taskService.createTaskQuery().taskDefinitionKey("usertask1")
				.singleResult();
		
		// get the list of fields in the form
		List<String> bpmnFieldNames = new ArrayList<>();
		TaskFormData taskFormData = activitiContext.getFormService().getTaskFormData(proposalsTask.getId());
		for (FormProperty fp : taskFormData.getFormProperties()){
			bpmnFieldNames.add(fp.getId());
		}
		
		// build a list of required fields that must be filled
		List<String> requiredFields = new ArrayList<>(
				Arrays.asList("aBallotCode"));
		
		// make sure that each of the required fields is in the form
		for (String requiredFieldName : requiredFields) {
			assertTrue(bpmnFieldNames.contains(requiredFieldName));
		}
		
		// make sure that each of the required fields was assigned a value
		for (String requiredFieldName : requiredFields) {
			assertTrue(formEntries.keySet().contains(requiredFieldName));
		}
		
		// submit the form (will lead to completing the use task)
		activitiContext.getFormService().submitTaskFormData(proposalsTask.getId(), formEntries);
	}
	
	
	@Test
	public void verifyFailure() throws Exception {
		startProcess();
		
		// Choosing a ballot code that does not exists in the database and filling the form using that code
		String aBallotCode = "B6055";
		fillBallotForm(aBallotCode);
		
		// Verify that the validation result variable is set to 2
		int validationResult = (int) activitiContext.getRuntimeService().getVariableLocal(processInstance.getId(), "validationResult");
		assertTrue(validationResult == 2);
		
	}
	
}
