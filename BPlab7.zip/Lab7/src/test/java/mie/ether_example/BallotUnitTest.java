package mie.ether_example;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;

public class BallotUnitTest extends LabBaseUnitTest {
	
	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/BallotDiagram.bpmn";
	}
	
	private void startProcess() {	
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process_pool1");
	}
	
	private void fillProposalsForm() {
		// form fields are filled using a map from field ids to values
		HashMap<String, String> formEntries = new HashMap<>();
		formEntries.put("aProposal1", "First Proposal");
		formEntries.put("aProposal2", "Second Proposal");
		formEntries.put("aProposal3", "Third Proposal");
		formEntries.put("aProposal4", "Fourth Proposal");
		
		// get the user task (collect proposals)
		TaskService taskService = activitiContext.getTaskService();
		Task proposalsTask = taskService.createTaskQuery().taskDefinitionKey("usertask1")
				.singleResult();
		
		// get the list of fields in the form
		List<String> bpmnFieldNames = new ArrayList<>();
		TaskFormData taskFormData = activitiContext.getFormService().getTaskFormData(proposalsTask.getId());
		for (FormProperty fp : taskFormData.getFormProperties()){
			bpmnFieldNames.add(fp.getId());
		}
		
		// build a list of required fields that must be filled
		List<String> requiredFields = new ArrayList<>(
				Arrays.asList("aProposal1", "aProposal2", "aProposal3", "aProposal4"));
		
		// make sure that each of the required fields is in the form
		for (String requiredFieldName : requiredFields) {
			assertTrue(bpmnFieldNames.contains(requiredFieldName));
		}
		
		// make sure that each of the required fields was assigned a value
		for (String requiredFieldName : requiredFields) {
			assertTrue(formEntries.keySet().contains(requiredFieldName));
		}
		
		// submit the form (will lead to completing the use task)
		activitiContext.getFormService().submitTaskFormData(proposalsTask.getId(), formEntries);
	}
	
	@Test
	public void runProcess() {
		startProcess();
		fillProposalsForm();
	}
	
}
