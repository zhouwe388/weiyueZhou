package com.mie.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.mie.model.Post;
import com.mie.model.Admin;
import com.mie.util.DbUtil;
import com.mie.util.connection;

public class PostDao {

	private Connection currentCon;
	public PostDao(){
		currentCon = DbUtil.getConnection();
	}

	public void postNew(Post newPost) {
		/** 
		 * This method adds a new post to the database
		 */

		try {
			PreparedStatement preparedStatement = currentCon
					.prepareStatement("INSERT INTO Post(PostID,Title,Username,Context,Likes,postdate,ProductName, Category) values (?, ?, ?, ?, ?, ?, ?, ?)");
			
			List<Post> all = getAllPosts();
			Iterator<Post> iterator = all.iterator();
			int lastid = 0;
			while(iterator.hasNext()){
				lastid = iterator.next().getid();
			}
			preparedStatement.setInt(1, lastid+1);
			preparedStatement.setString(2, newPost.getTitle());
			preparedStatement.setString(3, newPost.getusername());
			preparedStatement.setString(4, newPost.getcontext());
			preparedStatement.setInt(5, 0);
			preparedStatement.setString(6, newPost.getPostdate());
			preparedStatement.setString(7, newPost.getProductname());
			preparedStatement.setString(8, newPost.getCategory());
			preparedStatement.executeUpdate();
			}
		
		 catch (SQLException ex) {
				ex.printStackTrace();
			}

	}
	
	public List<Post> getAllPosts() {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Post> posts = new ArrayList<Post>();
		try {
			Statement statement = currentCon.createStatement();
			// System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from Post");
			while (rs.next()) {
				Post post = new Post();
				post.setid(rs.getInt("PostID"));
				post.setTitle(rs.getString("Title"));
				post.setusername(rs.getString("Username"));
				post.setContext(rs.getString("Context"));
				post.setLikes(rs.getInt("Likes"));
				post.setPostdate(rs.getString("postdate"));
				post.setProductname(rs.getString("ProductName"));
				post.setcategory(rs.getString("category"));
				posts.add(post);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return posts;
	}
	
	
	public List<Post> getCurrentUserAllPosts(String username){
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Post> posts = new ArrayList<Post>();
		try {
			Statement statement = currentCon.createStatement();
			// System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from Post WHERE Username='" +username +"'" );
			while (rs.next()) {
				Post post = new Post();
				post.setid(rs.getInt("PostID"));
				post.setTitle(rs.getString("Title"));
				post.setusername(rs.getString("Username"));
				post.setContext(rs.getString("Context"));
				post.setLikes(rs.getInt("Likes"));
				post.setPostdate(rs.getString("postdate"));
				post.setProductname(rs.getString("ProductName"));
				post.setcategory(rs.getString("category"));
				posts.add(post);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return posts;
	}
	
	public ArrayList<Post> getPostByKeyword(String keyword) {
		/**
		 * This method retrieves a list of posts that matches the keyword
		 * entered by the user.
		 */
		ArrayList<Post> posts = new ArrayList<Post>();
		try {
			PreparedStatement preparedStatement = currentCon
					.prepareStatement("select * from Post where Title LIKE ? OR ProductName LIKE ? OR Context LIKE ? ");
			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			//preparedStatement.setString(4, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Post post = new Post();
				post.setid(rs.getInt("PostID"));
				post.setTitle(rs.getString("Title"));
				post.setusername(rs.getString("Username"));
				post.setContext(rs.getString("Context"));
				post.setLikes(rs.getInt("Likes"));
				post.setPostdate(rs.getString("postdate"));
				post.setProductname(rs.getString("ProductName"));
				post.setcategory(rs.getString("category"));
				
				posts.add(post);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return posts;
	}
	
	public List<Post> getIndividualPost(Integer id) {
		/**
		 * This method retrieves a list of posts that matches the keyword
		 * entered by the user.
		 */
		List<Post> temposts = new ArrayList<Post>();
		try {
			PreparedStatement preparedStatement = currentCon
					.prepareStatement("select * from Post where PostID = ? ");
			preparedStatement.setInt(1, id);
	
			//preparedStatement.setString(4, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Post post = new Post();
				post.setid(rs.getInt("PostID"));
				post.setTitle(rs.getString("Title"));
				post.setusername(rs.getString("Username"));
				post.setContext(rs.getString("Context"));
				post.setLikes(rs.getInt("Likes"));
				post.setPostdate(rs.getString("postdate"));
				post.setProductname(rs.getString("ProductName"));
				post.setcategory(rs.getString("category"));
				
				temposts.add(post);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return temposts;
	}
	
	public Integer getpostid(Post xx){
		this.getPostByKeyword("stf");
		return null;
		
	}
	
	public Integer updatelikes(Integer postID){
		PreparedStatement preparedStatement;
		PreparedStatement preparedStatement2;
    	Integer templike = 0;
		
		Integer id=0;
		try {
			preparedStatement = currentCon.prepareStatement("SELECT * FROM Post WHERE PostID= ?");
			preparedStatement.setInt(1, postID);
			
			ResultSet rs= preparedStatement.executeQuery();
		
		while (rs.next()){ // should only repeat onces since one post id has one line in the DB
			id = rs.getInt("PostID");
			templike = rs.getInt("Likes");
			//System.out.print(rs.getInt("Likes"));
		
		
		}}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		   try {
			preparedStatement2= currentCon.prepareStatement("UPDATE Post SET Likes=? WHERE PostID= ? ;");
//			preparedStatement= currentCon.prepareStatement("INSERT INTO Post Values('" + 14 + "', '"+"fsdf" + "', '"+ "apple" + "', '"+ "sgsdf" + "', '"+ 2 + 
//	    		"', '"+ "2018-19-25 09:19:19" + "', '"+ "gggg" + "', '"+ "Electronics" + "')");
			preparedStatement2.setInt(1,templike+1);
			preparedStatement2.setInt(2,postID);
			preparedStatement2.executeUpdate();

				}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			return 2;   
	}
		
	
	
	public Integer getcurrentlikes(Integer postID){
		PreparedStatement preparedStatement;
		PreparedStatement preparedStatement2;
		Integer templike = 0;
		Integer id=0;
		try {
			preparedStatement = currentCon.prepareStatement("SELECT PostID, Likes FROM Post WHERE POSTID= ?");
			preparedStatement.setInt(1, postID);
			
			ResultSet rs= preparedStatement.executeQuery();
		while (rs.next()){ // should only repeat onces since one post id has one line in the DB
			id = rs.getInt("PostID");
			templike = rs.getInt("Likes");
			
		}
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 return templike;
}
}
