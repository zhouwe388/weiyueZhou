package com.mie.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mie.model.Expert;
import com.mie.util.DbUtil;
public class ExpertDao {

	static Connection currentCon = null;
	static ResultSet rs = null;
	
	public int getinterestid(Expert interest) {
		String field1 = interest.getfield1();
		String field2 = interest.getfield2();
		String level = interest.getlevel();
		Statement stmt=null;
		int id=0;
		
		String searchQuery = "select * from Expert where field1='"
				+ field1 + "' AND field2='" + field2 + "'AND experienceLevel='"+level+"'";
		try {
			// connect to DB
			currentCon = DbUtil.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */			
			if (more) {
				id = rs.getInt("interestID");
			}
			else{
				return id=0;
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		  return id;
	}
	
}
