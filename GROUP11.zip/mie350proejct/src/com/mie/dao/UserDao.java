package com.mie.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mie.model.*;
import com.mie.util.*;
import com.mie.dao.*;

import java.text.SimpleDateFormat;





public class UserDao {
	/**
	 * This class handles the Member objects and the login component of the web
	 * app.
	 */
	static Connection currentCon = null;
	static ResultSet rs = null;
	
	public UserDao() {
		/**
		 * Get the database connection.
		 */
		currentCon = connection.getConnection();
	}

	public static User login(User user) {

		/**
		 * This method attempts to find the member that is trying to log in by
		 * first retrieving the username and password entered by the user.
		 */
		Statement stmt = null;

		String username = user.getUsername();
		String password = user.getPassword();

		/**
		 * Prepare a query that searches the members table in the database
		 * with the given username and password.
		 */
		String searchQuery = "select * from User where username='"
				+ username + "' AND password='" + password + "'";

		try {
			// connect to DB
			currentCon = connection.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			
			if (!more) {
				user.setvalid(false);
				
			}

			/**
			 * If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to
			 * the Member object.
			 */
			else if (more) {
				String firstName = rs.getString("firstname");
				String lastName = rs.getString("lastname");

				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setvalid(true);
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/**
		 * Return the Member object.
		 */
		return user;

	}
	
	public void add(User user){
//		 Statement stmt = null;
//		 
//		 String username = user.getUsername();
//		 String email= user.getEmail();
//		 String fn=user.getFirstName();
//		 String mn=user.getmiddlename();
//		 String ln=user.getLastName();
//		 String bd= user.getdate();//?
//		 String password =user.getPassword();
//		 int interestId= user.getinterestid();
//		 
//		 String insertQuery = "INSERT INTO User Values('"+username+"','"+fn+"','"+ln+"','"+mn+"','"+bd+"','"+password+"','"+email+"','"+interestId+"')"; 
//		 
		try {
			PreparedStatement preparedStatement = currentCon
					.prepareStatement("INSERT INTO User(username,firstname,lastname,middlename,birthday,password,email,interestID) values (?, ?, ?, ?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getFirstName());
			preparedStatement.setString(3, user.getLastName());
			preparedStatement.setString(4, user.getmiddlename());
			preparedStatement.setString(5, user.getdate());
			preparedStatement.setString(6,user.getPassword());
			preparedStatement.setString(7, user.getEmail());
			preparedStatement.setInt(8,user.getinterestid());
			preparedStatement.executeUpdate();
			}
		
		 catch (Exception ex) {
				System.out.println("Log In failed: An Exception has occurred! insert error "
						+ ex);
			}
	}
	
	public static User checkusername(User user){
		Statement stmt=null;
		
		String username=user.getUsername();
		
		String searchQuery= "select * from User where username='" + username + "'";
		
		try{
			currentCon = connection.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();
			
			if (!more) {
				user.setvalid(false);
				
			}

			/**
			 * If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to
			 * the Member object.
			 */
			else if (more) {
//				
//				String realusername = rs.getString("username");
//
//				user.setUsername(realusername);
//				
				user.setvalid(true);
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! checkUsername "
					+ ex);
		}
		/**
		 * Return the Member object.
		 */
		return user;

		}
		
	}



