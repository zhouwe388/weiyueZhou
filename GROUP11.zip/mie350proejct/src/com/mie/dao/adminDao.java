package com.mie.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mie.model.*;
import com.mie.util.*;
import com.mie.dao.*;

import java.text.SimpleDateFormat;





public class adminDao {
	/**
	 * This class handles the Member objects and the login component of the web
	 * app.
	 */
	static Connection currentCon = null;
	static ResultSet rs = null;
	
	public adminDao() {
		/**
		 * Get the database connection.
		 */
		currentCon = connection.getConnection();
	}

	public static Admin login(Admin admin) {

		/**
		 * This method attempts to find the member that is trying to log in by
		 * first retrieving the username and password entered by the user.
		 */
		Statement stmt = null;

		String firstname = admin.getFirstName();
		String password = admin.getPassword();

		/**
		 * Prepare a query that searches the members table in the database
		 * with the given username and password.
		 */
		String searchQuery = "select * from Admin where firstname='"
				+ firstname + "' AND password='" + password + "'";

		try {
			// connect to DB
			currentCon = connection.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			if (!more) {
				admin.setvalid(false);
				
			}
			else if (more) {
//				
//				String realusername = rs.getString("username");
//
//				user.setUsername(realusername);
//				
				admin.setvalid(true);
			}

			

			/**
			 * If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to
			 * the Member object.
			 */
			
				String firstName = rs.getString("firstname");
				String lastName = rs.getString("lastname");

				admin.setFirstName(firstName);
				admin.setLastName(lastName);
	
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/**
		 * Return the Member object.
		 */
		return admin;

	}
	

		
	}




