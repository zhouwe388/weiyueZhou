package com.mie.model;

import java.util.Date;

public class Archived {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	private int postid;
	private String username;


	public int getpostid() {
		return postid;
	}

	public void setpostid(int postid) {
		this.postid = postid;
	}

	public String getusername() {
		return username;
	}

	public void setFirstName(String username) {
		this.username = username;
	}

}
