package com.mie.model;

import java.util.Date;

public class User {
	
	private String firstName;
	private String lastName;
	private String middlename;
	private String username;
	private String password;
	private String email;
	private boolean valid;

	private String birthday;
	private int interestid;

	public String getmiddlename() {
		return middlename;
	}

	public void setmiddlename(String name) {
		this.middlename = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	public boolean isValid() {
//		return valid;
//	}
//
//	public void setValid(boolean newValid) {
//		valid = newValid;
//	}
	

	
	public String getdate() {
		return birthday;
	}
	
	public void setbirthday(String birthdayx) {
		this.birthday= birthdayx;
	}
	
	public int getinterestid(){
		return interestid;
	}
	
	public  boolean isvalid(){
		return valid;
	}
	public void setvalid(boolean newvaild){
		valid= newvaild;
	}
	public void setinterestid(int interestdd){
		this.interestid= interestdd;
	}
	

	@Override
	public String toString() {
		return "User [username=" + username  + ", firstName=" + firstName + ", middlename" + middlename
				+ ", lastName=" + lastName + ", password=" + password + ", email=" + email  + ", Birthday" + birthday + "]";
	}

}
