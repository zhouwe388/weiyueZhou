package com.mie.model;

import java.util.Date;

public class Admin {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Member object.
	 */
	private int adminID;
	private String firstName;
	private String lastName;
	private String adminlevel;
	private String password;
	private boolean valid;


	public int getadminid() {
		return adminID;
	}

	public void setadminid(int id) {
		this.adminID = id;
	}
	
	public String getadminlevel(){
		return adminlevel;
	}
	
	public void setadminlevel(String level){
		this.adminlevel= level;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public boolean getvalid(){
		return valid;
		
	}
	
	public void setvalid(boolean valid){
		this.valid=valid;
	}


}
