package com.mie.model;

import java.util.Date;

public class Expert {
	
    private int interestID;
	private String field1;
	private String field2;
	private String experiencelevel;

	
	public void setid(int id){
		this.interestID = id;
	}


	public String getfield2() {
		return field2;
	}

	public void setfield2(String field2) {
		this.field2 = field2;
	}
	
	public String getfield1() {
		return field1;
	}

	public void setfield1(String field1) {
		this.field1 = field1;
	}
	
	public String getlevel() {
		return experiencelevel;
	}
	
	public void setlevel(String level) {
		this.experiencelevel= level;
	}
	

	
//	@Override
//	public String toString() {
//		return "Expert [username=" + username  + ", firstName=" + firstName + ", middlename" + middlename
//				+ ", lastName=" + lastName + ", password=" + password + ", email=" + email + ", Expertise" 
//				+ Expertise + ", Birthday" + birthday + "]";
//	}

}



