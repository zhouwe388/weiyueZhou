package com.mie.model;

import java.sql.Date;


public class Post {
	
    private int postID;
	private String title;
	private String username;
	private String context;
	private int likes;
	private String postdate;
	private String tags;
	private String category;

	
	public void setid(int id){
		this.postID = id;
	}
	public int getid(){
		return postID;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String newtitle) {
		this.title = newtitle;
	}
	
	public String getusername() {
		return username;
	}
	
	public void setusername(String name) {
		this.username = name;
	}
	
	public String getcontext() {
		return context;
	}
	public void setContext (String con) {
		this.context = con;
	}
	
	public int getLikes() {
		return likes;
	}
	public void setLikes(int like) {
		this.likes= like;
	}

	public String getPostdate() {
		return postdate;
	}
	public void setPostdate (String currentDate) {
		this.postdate= currentDate;
	}

	public String getProductname() {
		return tags;
	}
	public void setProductname(String tag) {
		this.tags= tag;
	}
	
	public String getCategory(){
		return category;
	}
	
	public void setcategory(String cate){
		this.category=cate;
	}

	
}



	




