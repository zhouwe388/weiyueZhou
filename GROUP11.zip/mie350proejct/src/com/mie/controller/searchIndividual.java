package com.mie.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.PostDao;

/**
 * Servlet implementation class searchIndividual
 */
public class searchIndividual extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static String AFTERX = "/afterSearchKeyword.jsp";
	private PostDao dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchIndividual() {
    	super();
    	dao = new PostDao();
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
HttpSession session = request.getSession(true);
		
		String action = request.getParameter("action");
		if (action.equalsIgnoreCase("view")) {
			int id = (Integer) request.getAttribute("individualid");
			RequestDispatcher view = request.getRequestDispatcher(AFTERX);
		
			session.setAttribute("individualid", id);
			request.setAttribute("individualid", id);
		
			session.setAttribute("post", dao.getIndividualPost(id));
			request.setAttribute("post", dao.getIndividualPost(id));
		
			view.forward(request, response);
		}
		
	}

}
