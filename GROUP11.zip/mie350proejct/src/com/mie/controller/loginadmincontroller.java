package com.mie.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.UserDao;
import com.mie.dao.adminDao;
import com.mie.model.Admin;
import com.mie.model.User;

/**
 * Servlet implementation class loginadmincontroller
 */
public class loginadmincontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginadmincontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * Retrieve the entered username and password from the login.jsp form.
		 */
		Admin admin = new Admin();
		admin.setFirstName(request.getParameter("un"));
		admin.setPassword(request.getParameter("pw"));

		try {
			/**
			 * Try to see if the member can log in.
			 */
			admin = adminDao.login(admin);

			/**
			 * If the isValid value is true, assign session attributes to the
			 * current member.
			 */
			if (admin.getvalid()) {

				HttpSession session = request.getSession(true);
				session.setAttribute("currentSessionmember", admin);
		
				session.setAttribute("firstname", admin.getFirstName());
				session.setAttribute("lastname", admin.getLastName());
				/**
				 * Redirect to the members-only home page.
				 */
				response.sendRedirect("AlogginPage.jsp");

				/**
				 * Set a timeout variable of 900 seconds (15 minutes) for this
				 * member who has logged into the system.
				 */
				session.setMaxInactiveInterval(900);
			}

			else {
				/**
				 * Otherwise, redirect the user to the invalid login page and
				 * ask them to log in again with the proper credentials.
				 */
				response.sendRedirect("invalidLogin.jsp");
			}
		}

		catch (Throwable theException) {
			/**
			 * Print out any errors.
			 */
			System.out.println(theException);
		}
	}




}
