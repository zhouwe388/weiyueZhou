package com.mie.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.PostDao;
import com.mie.dao.UserDao;
import com.mie.model.Post;

/**
 * Servlet implementation class postcontroller
 */
public class postcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String LIST_POST = "/displayNewPost.jsp";

	private PostDao postdao;
	private UserDao userdao;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public postcontroller() {
    	 super();
         postdao = new PostDao(); 
         userdao = new UserDao();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doAll(HttpServletRequest request,
//			HttpServletResponse response) throws ServletException, IOException {
//		String forward = "";
//		String action = request.getParameter("action");
//		if(action.equalsIgnoreCase("listPosts")){
//			forward = LIST_POST;
//			request.setAttribute("posts", postdao.getAllPosts());
//		}
//		RequestDispatcher view = request.getRequestDispatcher(forward);
//		view.forward(request, response);
//	}
    
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		//session.setAttribute("username","apple");
		// TODO Auto-generated method stub
		Post post = new Post();
		//postid autogenerate????
		
		post.setTitle(request.getParameter("title"));
		String temp= (String)session.getAttribute("username");
	    post.setusername(temp);
	    //are they going to enter their username??
		post.setContext(request.getParameter("textarea"));
		post.setLikes(0);
	
		post.setProductname(request.getParameter("prodname"));
		post.setcategory(request.getParameter("category"));
		
		Date currentDate =  Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strDate = dateFormat.format(currentDate);
		post.setPostdate(strDate);
		
//		try {
//			post.setPostdate(new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("???auto")));	
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
		
//			HttpSession session = request.getSession(true);
			
			postdao.postNew(post);
			session.setAttribute("currentPost", post);

		  session.setAttribute("username", post.getusername());
			
				/**
				 * Redirect to the members-only home page.
				 */
		  RequestDispatcher view = request
					.getRequestDispatcher(LIST_POST);
			request.setAttribute("posts", postdao.getCurrentUserAllPosts(post.getusername()));
			request.setAttribute("tempposts", postdao.getIndividualPost(post.getid()));
			request.setAttribute("keyword", post.getTitle());
			System.out.print("xxxx");
			view.forward(request, response);	
		  
		  //response.sendRedirect("displayNewPost.jsp");
			}
	}

	


