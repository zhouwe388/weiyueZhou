package com.mie.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.PostDao;
import com.mie.model.Post;

/**
 * Servlet implementation class searchcontroller
 */
public class searchcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String SEARCH_POST = "/searchProductResultAnyone.jsp";
	private static String AFTERX = "/afterSearchKeyword.jsp";
	private PostDao dao;
	
    public searchcontroller() {
        super();
    	dao = new PostDao();
       
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

    
    
    
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String keyword = request.getParameter("keyword");

		RequestDispatcher view = request.getRequestDispatcher(SEARCH_POST);
		session.setAttribute("keyword", keyword);
		request.setAttribute("keyword", keyword);
		
		
		session.setAttribute("posts", dao.getPostByKeyword(keyword));
		request.setAttribute("posts", dao.getPostByKeyword(keyword));
		
		session.setAttribute("tempposts", dao.getPostByKeyword(keyword));
		request.setAttribute("tempposts", dao.getPostByKeyword(keyword));
		

		/**
		 * Redirect to the search results page after the list of students
		 * matching the keywords has been retrieved.
		 */
		
		view.forward(request, response);
	}

}
