package com.mie.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.mie.dao.ExpertDao;

import com.mie.dao.UserDao;
import com.mie.model.User;
import com.mie.model.Expert;
/**
 * Servlet implementation class SignUpController
 */
public class SignUpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ExpertDao dao;   
	private UserDao userdao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpController() {
        super();
        dao = new ExpertDao();
        userdao = new UserDao();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * Retrieve the entered username and password from the login.jsp form.
		 */
		User user = new User();
		//
		user.setUsername(request.getParameter("un"));
		user.setEmail(request.getParameter("email"));
		user.setPassword(request.getParameter("pw"));
//		try {
//			user.setbirthday(new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("birthday")));
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		//  <br> Birthday: <input type="date" name="birthday"/>
		user.setbirthday(request.getParameter("bd"));/////.......
		user.setFirstName(request.getParameter("fn"));
		user.setLastName(request.getParameter("ln"));
		user.setmiddlename(request.getParameter("middlename"));
		
		Expert expert= new Expert();
		expert.setfield1(request.getParameter("interest1"));
		expert.setfield2(request.getParameter("interest2"));
		expert.setlevel(request.getParameter("level"));//is related to front
		user.setinterestid(dao.getinterestid(expert));
		expert.setid(user.getinterestid());
		
	
		try {
			/**
			 * Try to see if the member can log in.
			 */
			user = UserDao.checkusername(user);

			/**
			 * If the isValid value is true, assign session attributes to the
			 * current member.
			 */
			if (user.isvalid()) {
				response.sendRedirect("usernametaken.jsp"); //the case where usename is taken, the customer has to sign up again with a different username
					
			}

			else {
				
				HttpSession session = request.getSession(true);
				userdao.add(user);
				session.setAttribute("currentSessionmember", user);
				session.setAttribute("username", user.getUsername());
			
				/**
				 * Redirect to the members-only home page.
				 */
				response.sendRedirect("login.jsp");
			}
		}

		catch (Throwable theException) {
			/**
			 * Print out any errors.
			 */
			System.out.println(theException);
		}
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	


