package com.mie.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.PostDao;
import com.mie.model.Post;
import com.mie.model.Admin;
import com.mie.util.DbUtil;

/**
 * Servlet implementation class likeupdate
 */
public class likeupdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PostDao postdao;
	private Connection currentCon;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public likeupdate() {
        super();
        postdao = new PostDao();
        currentCon = DbUtil.getConnection();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a student in
		 * the database. - insert will direct the servlet to let the user add a
		 * new student to the database. - edit will direct the servlet to let
		 * the user edit student information in the database. - listStudent will
		 * direct the servlet to the public listing of all students in the
		 * database. - listStudentAdmin will direct the servlet to the admin
		 * listing of all students in the database.
		 */
//		String forward = "";
//		String action = request.getParameter("action"); // when the backend rececived 
		HttpSession session = request.getSession(true);
		PreparedStatement preparedStatement;
		//session.setAttribute("unxx", request.getParameter("currentlike"));
		//if(request.getParameter("currentlike").equals("Like")){
			
		
//		String action = request.getParameter("like");
//		System.out.print(action);

//		if (action.equalsIgnoreCase("like")) {
		Integer id =0;
		ArrayList<Post> newpost =postdao.getPostByKeyword((String) session.getAttribute("keyword"));
		for(Post i : newpost){
			id= i.getid();
		}
		System.out.print(id);
		postdao.updatelikes(id);
			

			//request.setAttribute("Likes", postdao.getcurrentlikes(id));
			session.setAttribute("posts", postdao.getPostByKeyword((String) session.getAttribute("keyword")));
			request.setAttribute("posts", postdao.getPostByKeyword((String) session.getAttribute("keyword")));
			response.sendRedirect("afterSearchKeyword.jsp");
		
	}}


