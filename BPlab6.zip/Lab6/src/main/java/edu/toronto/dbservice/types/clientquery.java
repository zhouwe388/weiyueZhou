package edu.toronto.dbservice.types;
import java.io.Serializable;

public class clientquery  implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer queryid;
	private String item;
	private Integer accountnum;
	
	public clientquery (Integer pid, Integer xaccountnum, String pItem) {
		queryid = pid;
		item = pItem;
		accountnum= xaccountnum;
	}
	
	public Integer getqueryid() {
		return queryid;
	}
	
	public String getItem() {
		return item;
	}
	
	public Integer getaccountnum(){
		return accountnum;
	}

}

