package mie.ether_example;

import java.sql.Connection;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import edu.toronto.dbservice.config.MIE354DBHelper;

public class getxxxxx implements JavaDelegate{ 
	Connection dbCon = null;

	public getxxxxx() {
		dbCon = MIE354DBHelper.getDBConnection();
	}
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
	
	}
}
