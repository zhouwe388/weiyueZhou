package mie.ether_example;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;

import edu.toronto.dbservice.types.EtherAccount;

// Run with parameters
public class Exercise1UnitTest extends LabBaseUnitTest {
	
	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/InvLab1_Registry.bpmn";
	}
	
	private void startProcess() {	
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process_pool1");
	}
	
	@Test
	public void checkDBUnregister() throws Exception {
		// Check process is paused at usertask1
		startProcess();
		assertNotNull(processInstance);
		
		Statement statement;
		ResultSet resultSet;
		
		// Count all the unregister requests in the database
		int unregisterRequestsCounter = 0;
		statement = dbCon.createStatement();
		resultSet = statement.executeQuery("SELECT * FROM Unregister");
		while (resultSet.next()) {
			unregisterRequestsCounter += 1;
		}
		
		// Assert based on the expected number of requests
		assertTrue(unregisterRequestsCounter == 4);
	}
	
}
