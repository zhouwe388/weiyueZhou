package mie.ether_example;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;

import edu.toronto.dbservice.types.EtherAccount;

// Run with parameters
@RunWith(Parameterized.class)
public class Exercise2UnitTest extends LabBaseUnitTest {
	private String phonenumberx;
	
	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/InvLab1_Registry.bpmn";
	}
	
	public Exercise2UnitTest(String numberxx){
		this.phonenumberx= numberxx;
	}
	
	@Parameterized.Parameters
	public static Collection<String> realphones(){
		ArrayList<String> parameters = new ArrayList<>();
		parameters.add(new String  ("999-1234"));
		parameters.add(new String( "999-2345"));
		parameters.add(new String( "999-3456"));
		parameters.add(new String ("999-6055"));
		return parameters;
		

	}
	
	private void startProcess() {	
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process_pool1");
	}
	
	@Test
	public void checkIfRegistered() throws Exception {
		// Check process is paused at usertask1
		startProcess();
		assertNotNull(processInstance);
		
		// connect to the blockchain and load the registry contract
		Web3j web3 = Web3j.build(new HttpService());
		String contractAddress = (String) activitiContext.getRuntimeService().getVariableLocal(processInstance.getId(), "contractAddress");
		HashMap<Integer, EtherAccount> accounts = (HashMap<Integer, EtherAccount>) activitiContext.getRuntimeService().getVariableLocal(processInstance.getId(), "accounts");
		Registry myRegistry = Registry.load(contractAddress, web3, accounts.get(0).getCredentials(), EtherUtils.GAS_PRICE, EtherUtils.GAS_LIMIT_CONTRACT_TX);
		
		// Check if phone number 999-1234 is registered
		String phoneNumber = phonenumberx;
		Utf8String encodedPhoneNumber = new Utf8String(phoneNumber);
		boolean isNumberRegistered = myRegistry.isRegistered(encodedPhoneNumber).get().getValue();
		
		// Assert that the number is registered
		assertTrue(isNumberRegistered);
	}
	
}
