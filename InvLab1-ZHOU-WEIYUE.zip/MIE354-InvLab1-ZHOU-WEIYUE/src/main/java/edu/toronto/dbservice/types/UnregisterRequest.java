package edu.toronto.dbservice.types;

import java.io.Serializable;

public class UnregisterRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer clientNum;
	private String item;
	
	public UnregisterRequest(Integer pClientNum, String pItem) {
		clientNum = pClientNum;
		item = pItem;
	}
	
	public Integer getClientNum() {
		return clientNum;
	}
	
	public String getItem() {
		return item;
	}

}