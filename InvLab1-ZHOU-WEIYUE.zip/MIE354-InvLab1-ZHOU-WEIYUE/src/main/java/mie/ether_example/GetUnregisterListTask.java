package mie.ether_example;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import edu.toronto.dbservice.config.MIE354DBHelper;
import edu.toronto.dbservice.types.UnregisterRequest;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class GetUnregisterListTask implements JavaDelegate{

	Connection dbCon = null;

	public GetUnregisterListTask() {
		dbCon = MIE354DBHelper.getDBConnection();
	}
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		// Selecting the unregister request list from the data table
		Statement statement;
		ResultSet resultSet = null;
		List<UnregisterRequest> unregisterRequestList = new ArrayList<>();
		
		// TODO: Load unregister requests from the database to the unregisterRequestList
		statement = dbCon.createStatement();
		resultSet = statement.executeQuery("SELECT * FROM Unregister");
		while (resultSet.next()) {
			Integer accountId = resultSet.getInt("account");
			
			String item = resultSet.getString("item");
			UnregisterRequest UnregisterRequestyeah = new UnregisterRequest(accountId, item);
			unregisterRequestList.add(UnregisterRequestyeah);
		}
		resultSet.close();
		
		
		// Saving the list of unregister requests as a process variable
		execution.setVariable("unregisterRequestList", unregisterRequestList);
	}

}
