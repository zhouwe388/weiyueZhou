/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tokenizer;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author zhouwe38
 */
public class IndexingTokenizer implements Tokenizer{
    public IndexingTokenizer(){
        
    }

    @Override
    public ArrayList<String> tokenize(String s) {
        ArrayList<String> ret = new ArrayList<String>();
		
		Matcher m = Pattern.compile("\\w+[-\\w]*").matcher(s);
		while (m.find()) {
			ret.add(m.group().toLowerCase());
			
        }
		return ret;
    }
    
}
