/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package index;



/**
 *
 * @author zhouwe38
 */
public class SortedDocScore extends DocScore implements Comparable<SortedDocScore>{

    public SortedDocScore(double score, int doc_id, String content) {
        super(score, doc_id, content);
    }

    
    public int compareTo(SortedDocScore o) {
        if (this._score > o._score) {
            return -1;
        } 
        else if (this._score < o._score) {
            return 1;
            
        } 
        else
            return this._content.compareTo(o._content);
      
    }
        
            
        
    
    
    public boolean equals(SortedDocScore o){
        return (_score == o._score) && (_content.equals(o._content));
           
        
    }
     
    }

