/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package index;

import io.DocSource;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.TreeSet;
import score.TermScoringFun;
import tokenizer.Tokenizer;

/**
 *
 * @author zhouwe38
 */
public class InvertedIndex extends Index{
    private HashMap<String,HashMap<Integer, Integer>> _index; //word(token) , <doc ID, term frequency in the doc with that ID>
    private HashMap<String,Integer> _docFreq; //<word, doc frequency with that word>

    public InvertedIndex(DocSource doc_source, Tokenizer tokenizer, TermScoringFun scoring) {
        super(doc_source, tokenizer, scoring);
        _index= new HashMap<>();
        _docFreq=new HashMap<>();
    }

    @Override
    
    public void buildIndex() {
      
    
        
        
        TreeSet<String> notrepeatedwords= new TreeSet();
    
     for(int i=0; i<_docSource.getNumDocs(); i++){
        
           ArrayList<String> newlist = _tokenizer.tokenize(_docSource.getDoc(i));//separate when getting a new file
           notrepeatedwords.addAll(newlist);
           
           for(String word : newlist){
               HashMap<Integer,Integer> smallmap= new HashMap(); //refresh for everysingle word
               
               if(_index.containsKey(word)==false){ //index dont have the word, never appeared
                   smallmap.put(i, 1);
                   //smallmap=newmap;
                   _index.put(word,smallmap);
               }
               else if(_index.containsKey(word) && _index.get(word).containsKey(i)){ //index has the word and the word has appeared in the file
                   smallmap=_index.get(word);//get all previous hashmaps
                   smallmap.put(i,  _index.get(word).get(i)+1);//get previous hashmap
                   _index.put(word,smallmap);


               }
               else if(_index.containsKey(word)&& _index.get(word).containsKey(i)==false){//index has appeared before but not in this particular file
                   smallmap=_index.get(word);//get all previous hashmap
                   smallmap.put(i, 1);
                   _index.put(word, smallmap);
                  
                  // System.out.print("2"+ _index.get(word));
                }
            
           }
     }
     
     
     for(String term: notrepeatedwords){
         if(_index.get(term).size()>0){
             _docFreq.put(term, _index.get(term).size());
         }
     }
     
     
    }

            
           
    @Override
    public int getDocumentFreq(String term) { //how many doc has the token
        return _docFreq.get(term);
    }

    @Override
    public ArrayList<DocScore> getSortedSearchResults(String query) {
         TreeSet<SortedDocScore> finallist= new TreeSet();
         
         ArrayList<DocScore> newlist=new ArrayList();
         double score;
         ArrayList<String> newstringlist=_tokenizer.tokenize(query); //separated

          for(int i =0; i<_docSource.getNumDocs(); i++){
              score=0.0; //refresh to next file when all word has been process.
              
              for(String word: newstringlist){
                  if(_index.containsKey(word) && _index.get(word).get(i)!=null){ //if word is in the dictionary && if the word frequency in that particular file not zero.

                        score= score+ _scoring.scoreToken(word, _index.get(word).get(i)); //complete when score is finished from addition of all words freq
                        //System.out.print(score);
                            
                       }
                    }
              //System.out.println("out");
              if(score > 0.0){ //if all or some of the words in query appeared in dict
                  SortedDocScore docsscore= new SortedDocScore(score,i,_docSource.getDoc(i));
                  finallist.add(docsscore);
              }

          }       
 
    
           newlist.addAll(finallist);
         return newlist;
    }
  

    @Override
 public String toString(){
     return this._index.toString();
     }
 
}