/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author zhouwe38
 */
public class FileDocSource extends DocSource{

    protected ArrayList<File> _files;
    
    public FileDocSource(String location){
        
            _files=FileFinder.GetAllFiles(location);
        }
        
    
    public int getNumDocs() {
        return _files.size();
    }

    @Override
    public String getDoc(int id) {
        StringBuilder news = new StringBuilder();
        String s;
        try {
            BufferedReader cin = new BufferedReader( new FileReader (_files.get(id)));
            
            while(((s = cin.readLine())!= null)){
                news.append(s);
            }
           cin.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileDocSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileDocSource.class.getName()).log(Level.SEVERE, null, ex);
        }
         
       return news.toString();
    }
    
    
    
    
}
