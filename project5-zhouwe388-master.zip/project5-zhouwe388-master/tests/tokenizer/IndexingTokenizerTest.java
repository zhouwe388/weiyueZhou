/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tokenizer;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zhouwe38
 */
public class IndexingTokenizerTest {
    
    public IndexingTokenizerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of tokenize method, of class IndexingTokenizer.
     */
    @Test
    public void testTokenize() {
        System.out.println("tokenize");
        String s = "new                               right&&&&&         --------yehhhhh yehhhh3425h   yehhh---- yehhhhh-5346    yuo  ";
        IndexingTokenizer instance = new IndexingTokenizer();
        ArrayList<String> expResult = new ArrayList();
        expResult.add("new");
        expResult.add("right");
        expResult.add("yehhhhh");
        expResult.add("yehhhh3425h");
        expResult.add("yehhh----");
        expResult.add("yehhhhh-5346");
        expResult.add("yuo");
        ArrayList<String> result = instance.tokenize(s);
        assertEquals(expResult, result);

    }
    
}
