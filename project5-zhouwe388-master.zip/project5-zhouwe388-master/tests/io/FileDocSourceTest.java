/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zhouwe38
 */
public class FileDocSourceTest {
    
    public FileDocSourceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNumDocs method, of class FileDocSource. check if right file counted
     */
    @Test
    public void testGetNumDocs() {
        System.out.println("getNumDocs");
        FileDocSource instance = new FileDocSource("\\\\SRVB\\Homes$\\zhouwe38\\Documents\\MIE250\\project5-zhouwe388\\file\\awards_1990\\awd_1990_06");
        int expResult = 287;
        int result = instance.getNumDocs();
        assertEquals(expResult, result);

    }

}
