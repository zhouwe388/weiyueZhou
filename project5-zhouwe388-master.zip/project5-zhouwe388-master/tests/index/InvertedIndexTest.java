/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package index;

import io.FileDocSource;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import score.TFIDFScoringFun;
import tokenizer.IndexingTokenizer;
import tokenizer.Tokenizer;

/**
 *
 * @author zhouwe38
 */
public class InvertedIndexTest {
    
    public InvertedIndexTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }



    /**
     * Test of getDocumentFreq method, of class InvertedIndex.
     */
    @Test
    public void testGetDocumentFreq() {
        System.out.println("getDocumentFreq");
        FileDocSource instance = new FileDocSource("\\\\SRVB\\Homes$\\zhouwe38\\Documents\\MIE250\\project5-zhouwe388\\file\\awards_1990\\awd_1990_01");
        //String allwords= instance.getDoc(0);
        Tokenizer tokenbreak = new IndexingTokenizer();
        TFIDFScoringFun scorecal = new TFIDFScoringFun();
        
        
        InvertedIndex index= new InvertedIndex(instance, tokenbreak, scorecal);
        index.buildIndex();
        int result = index.getDocumentFreq("material");
        int expResult= 26;
        assertEquals(expResult, result);
   
    }

    /**
     * Test of getSortedSearchResults method, of class InvertedIndex.
     */
    @Test
    public void testGetSortedSearchResults() {
       FileDocSource instance = new FileDocSource("\\\\SRVB\\Homes$\\zhouwe38\\Documents\\MIE250\\project5-zhouwe388\\file\\awards_1990\\awd_1990_01");
        //String allwords= instance.getDoc(0);
        Tokenizer tokenbreak = new IndexingTokenizer();
        TFIDFScoringFun scorecal = new TFIDFScoringFun();
        
        
        InvertedIndex index= new InvertedIndex(instance, tokenbreak, scorecal);
        index.buildIndex();
        ArrayList<DocScore> expResult = new ArrayList();
        ArrayList<DocScore> result = index.getSortedSearchResults("materl");
        assertEquals(expResult, result);

    }


    
}
