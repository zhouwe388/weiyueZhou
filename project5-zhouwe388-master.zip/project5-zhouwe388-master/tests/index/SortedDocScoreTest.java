/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package index;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zhouwe38
 */
public class SortedDocScoreTest {
    
    public SortedDocScoreTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of compareTo method, of class SortedDocScore.
     */
    @Test
    public void testCompareTo() {
        System.out.println("compareTo");
        SortedDocScore o = new SortedDocScore(0.777, 1, "one");
        SortedDocScore instance = new SortedDocScore(0.877, 3, "twe");;
        int expResult = -1;
        int result = instance.compareTo(o);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of compareTo method, of class SortedDocScore.
     */
    @Test
    public void test2ofCompareTo() {
        System.out.println("compareTotest2");
        SortedDocScore o = new SortedDocScore(0.777, 1, "one");
        SortedDocScore instance = new SortedDocScore(0.777, 4, "One");;
        int expResult = "One".compareTo("one");;
        int result = instance.compareTo(o);
        assertEquals(expResult, result);
    }
    
        /**
     * Test of compareTo method, of class SortedDocScore.
     */
    @Test
    public void test3ofCompareTo() {
        System.out.println("compareTo");
        SortedDocScore o = new SortedDocScore(0.777, 1, "one");
        SortedDocScore instance = new SortedDocScore(0.777, 1, "Sprte");;
        int expResult = "Sprte".compareTo("one");
        int result = instance.compareTo(o);
        assertEquals(expResult, result);
    
}
}
