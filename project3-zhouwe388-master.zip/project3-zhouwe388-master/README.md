# MIE250 Project 3

Please see the assignment description posted on Blackboard for instructions.
