package mie.test_example;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import edu.toronto.dbservice.exceptions.SQLExceptionHandler;
import edu.toronto.dbservice.config.MIE354DBHelper;
import edu.toronto.dbservice.types.Person;

public class Lab5_2UnitTest extends LabBaseUnitTest {

	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/lab5_2.bpmn";
	}

	public void submitFormData() {
		Task usertask1 = activitiContext.getTaskService().createTaskQuery().taskDefinitionKey("usertask1")
				.singleResult();

		// One way to complete any task (even if it includes as form) is to call
		// the method TaskService.complete(taskid). Another way to complete a
		// task that has a form is to submit the task's form data

		// form fields are filled using a map from form field ids to values
		HashMap<String, String> formEntries = new HashMap<String, String>();
		formEntries.put("num_rows", "3");

		// checks that the task's form fields have been assigned// get the user task (Pause Task)
		TaskService taskService = activitiContext.getTaskService();
		Task proposalsTask = taskService.createTaskQuery().taskDefinitionKey("usertask1")
				.singleResult();
		
		// submit the form (will lead to completing the user task)
		activitiContext.getFormService().submitTaskFormData(proposalsTask.getId(), formEntries);
	}
	
	private void startProcess() {
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process1");
	}
	@Test
	public void testCheckPausedAtFirstUserTask() {
		startProcess();
		System.out.println("id " + processInstance.getId() + " " + processInstance.getProcessDefinitionId());
		assertNotNull(processInstance);
		assertPendingTaskSize(1);
		ArrayList<String> pendingTaskNames = getPendingTaskNames();
		assertTrue(getPendingTaskNames().contains("Enter the number of persons"));
		ArrayList<String> pendingTaskIds = getPendingTaskIds();
		assertTrue(getPendingTaskIds().contains("usertask1"));
	}
	
	
	
	public void testPersonList() {
		//testCheckPausedAtFirstUserTask();
		ArrayList<Person> plist = (ArrayList<Person>) activitiContext.getRuntimeService().getVariable(
				processInstance.getId(), "personList");
		assertTrue(plist.size() > 0);

	}
	
	@Test
	public void testConfirmSalaries() {
	
		startProcess();
		submitFormData();		
		assertPendingTaskSize(1);
		testPersonList();
		//Integer num_row = 1;//get it from parameterized ;
	
		ArrayList<Person> outputTable = getOutputTable();
		assertTrue(outputTable.size() > 0);
		System.out.println("outputTable:"+outputTable);
		for (Person p : outputTable) {
			assertTrue (p.newsalary == p.salary*1.5 );
			System.out.println("name: "+p.name);
			System.out.println("pnewsalary:"+p.newsalary);
			System.out.println("psalary:"+p.salary);
		}
		
	}
	

	//num_row is the value that you input in the submitFormData()
	//To get the first num_row rows from the database
	private ArrayList<Person> getOutputTable() {
		Connection dbCon = MIE354DBHelper.getDBConnection();
		
		Statement statement;
		ResultSet resultSet = null;
		ArrayList<Person> personList = new ArrayList<Person>();
		try {
			statement = dbCon.createStatement();
			resultSet = statement.executeQuery("SELECT people.name, people.salary, outputtable.salary as newsalary FROM outputtable, people WHERE people.name = outputtable.name");
			Integer i = 1;
			while (resultSet.next()) {
				String pName = resultSet.getString("name");
				int pSalary = resultSet.getInt("salary");
				int newsalary = resultSet.getInt("newsalary");
				Person p = new Person(pName, pSalary);
				p.newsalary = newsalary; 
				personList.add(p);
				i++;
			}

			resultSet.close();
			statement.close();
			dbCon.close();
		} catch (SQLException se) {
			SQLExceptionHandler.handleException(se);
		}
		return personList;
	}

	@Test
	public void testProcessEnded() {
		testConfirmSalaries();
		completeAllPendingTasks();
		assertPendingTaskSize(0);
	}

	private ArrayList<String> getPendingTaskNames() {
		ArrayList<String> taskListNames = new ArrayList<String>();
		for (Task t : activitiContext.getTaskService().createTaskQuery().list()) {
			taskListNames.add(t.getName());
		}
		return taskListNames;
	}

	private ArrayList<String> getPendingTaskIds() {
		ArrayList<String> taskListIds = new ArrayList<String>();
		for (Task t : activitiContext.getTaskService().createTaskQuery().list()) {
			taskListIds.add(t.getTaskDefinitionKey());
		}
		return taskListIds;
	}

	private void assertPendingTaskSize(int num) {
		List<Task> list3 = activitiContext.getTaskService().createTaskQuery().list();
		assertTrue(list3.size() == num);
	}

	private void completeAllPendingTasks() {
		List<Task> list2 = activitiContext.getTaskService().createTaskQuery().list();
		for (Task t : list2) {
			System.out.println("completing task:" + t.getName());
			activitiContext.getTaskService().complete(t.getId());
		}
	}

	private void showPendingTasks() {
		System.out.println("Printing pending tasks...");
		List<Task> list = activitiContext.getTaskService().createTaskQuery().list();
		if (list.size() == 0) {
			System.out.println("Pending task list size is zero.");
		}
		for (Task t : list) {
			System.out.println("pending task:" + t.getId() + ":" + t.getName());
		}
	}

}