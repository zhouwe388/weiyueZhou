package mie.test_example;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.form.FormProperty;
import org.activiti.engine.form.TaskFormData;
import org.activiti.engine.task.Task;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

// RUN WITH PARAMETERS
@RunWith(Parameterized.class)
public class Lab5_1UnitTest extends LabBaseUnitTest {

	@BeforeClass
	public static void setupFile() {
		filename = "src/main/resources/diagrams/lab5_1.bpmn";
	}

	// START OF PARAMETERIZED CODE
	private String aNameParameter;
	private String aValueParameter;

	// Constructor has two string parameters
	public Lab5_1UnitTest(String namePrm, String valPrm) {
		this.aNameParameter = namePrm;
		this.aValueParameter = valPrm;
	}

	// Setup parameters to provide pairs of strings to the constructor
	@Parameters
	public static Collection<String[]> data() {
		ArrayList<String[]> parameters = new ArrayList<String[]>();
		//add one more parameter and change number, only have three available, two for students
		parameters.add(new String[]{ "Person1", "3000"});
		parameters.add(new String[]{ "Person2", "8000"});
		parameters.add(new String[]{ "Person3", "15000"});
		parameters.add(new String[]{ "Person4", "25000"});
		parameters.add(new String[]{ "Person5", "35000"});
		parameters.add(new String[]{ "Person6", "20000"});
		return parameters;
	}
	// END OF PARAMETERIZED CODE

	public void submitFormData() {
		Task usertask1 = activitiContext.getTaskService().createTaskQuery().taskDefinitionKey("usertask1")
				.singleResult();

		// One way to complete any task (even if it includes as form) is to call
		// the method TaskService.complete(taskid). Another way to complete a
		// task that has a form is to submit the task's form data

		// form fields are filled using a map from form field ids to values
		HashMap<String, String> formEntries = new HashMap<String, String>();
		// formEntries.put("aName", "Person1");
		// formEntries.put("aValue", "100");

		formEntries.put("aName", aNameParameter);
		formEntries.put("aValue", aValueParameter);

		
		// check that the right form fields have been created
		ArrayList<String> bpmnFieldNames = new ArrayList<String>();
		// get the list of form fields
		TaskFormData taskFormData = activitiContext.getFormService().getTaskFormData(usertask1.getId());
		for (FormProperty fp : taskFormData.getFormProperties()) {
			bpmnFieldNames.add(fp.getName());
		}

		// get the list of form fields that need to be present
		ArrayList<String> requiredFieldNames = new ArrayList<String>();
		requiredFieldNames.add("aName");
		requiredFieldNames.add("aValue");
		// do the check by ensuring the presence of field names
		for (String requiredFieldName : requiredFieldNames) {
			assertTrue(bpmnFieldNames.contains(requiredFieldName));
		}

		// do the check that ensures that the form fields have been assigned
		// values
		for (FormProperty fp : taskFormData.getFormProperties()) {
			assertTrue(formEntries.keySet().contains(fp.getName()));
		}

		// submit the form data using the form service
		activitiContext.getFormService().submitTaskFormData(usertask1.getId(), formEntries);
	}

	private void startProcess() {
		RuntimeService runtimeService = activitiContext.getRuntimeService();
		processInstance = runtimeService.startProcessInstanceByKey("process1");
	}

	@Test
	public void startProcessTest() {
		startProcess();
		assertNotNull(processInstance.getId());
		System.out.println("id .....eee" + processInstance.getId() + " " + processInstance.getProcessDefinitionId());
	}

	@Test
	public void testCheckPausedAtFirstUserTask() {
		startProcess();
		assertNotNull(processInstance);
		assertPendingTaskSize(1);
	}

	@Test
	public void testCheckMultipleChoice() {
		testCheckPausedAtFirstUserTask();
		submitFormData();

		Integer aValueVar = Integer.parseInt(activitiContext.getRuntimeService()
				.getVariable(processInstance.getId(), "aValue").toString());
		
		
		if (aValueVar > 30000){
			assertPendingTaskSize(1);
			assertTrue(getPendingTaskNames().contains("Asset Verification"));
			
			
		} else if (aValueVar > 20000 && aValueVar <= 30000){
			assertPendingTaskSize(2);
			assertTrue(getPendingTaskNames().contains("Asset Verification"));
			assertTrue(getPendingTaskNames().contains("Credit Report Rating"));
			
		} else if (aValueVar >= 15000 && aValueVar <= 20000) {
			assertPendingTaskSize(3);
			assertTrue(getPendingTaskNames().contains("Credit Report Rating"));
			assertTrue(getPendingTaskNames().contains("Bankruptcy List"));
			assertTrue(getPendingTaskNames().contains("Asset Verification"));
			
		} else if (aValueVar > 10000 && aValueVar <= 15000) {
				assertPendingTaskSize(1);
				assertTrue(getPendingTaskNames().contains("Asset Verification")); 

		} else if (aValueVar <=10000){
			assertPendingTaskSize(1);
			assertTrue(getPendingTaskNames().contains("Bankruptcy List"));
		
		}

	}

	@Test
	public void testAtMakeDecision() {
		testCheckMultipleChoice();
		showPendingTasks();
		completeAllPendingTasks();
		
		
		List<Task> list = activitiContext.getTaskService().createTaskQuery().list();
		Integer num = list.size();
		showPendingTasks();
		//assert pending task based on the multi-choice
		assertPendingTaskSize(num);
		
		
		
		assertTrue(getPendingTaskNames().contains("Make Decision"));
		assertTrue(getPendingTaskDefinitionKeys().contains("usertask8"));
	}
	
	@Test
	public void testProcessEnded() {
		testAtMakeDecision();
		completeAllPendingTasks();
		assertPendingTaskSize(0);
	}

	private ArrayList<String> getPendingTaskNames() {
		ArrayList<String> taskListNames = new ArrayList<String>();
		for (Task t : activitiContext.getTaskService().createTaskQuery().list()) {
			taskListNames.add(t.getName());
		}
		return taskListNames;
	}

	private ArrayList<String> getPendingTaskDefinitionKeys() {
		ArrayList<String> taskListIds = new ArrayList<String>();
		for (Task t : activitiContext.getTaskService().createTaskQuery().list()) {
			taskListIds.add(t.getTaskDefinitionKey());
		}
		return taskListIds;
	}

	private void assertPendingTaskSize(int num) {
		List<Task> list3 = activitiContext.getTaskService().createTaskQuery().list();
		assertTrue(list3.size() == num);
	}

	private void completeAllPendingTasks() {
		List<Task> list2 = activitiContext.getTaskService().createTaskQuery().list();
		for (Task t : list2) {
			System.out.println("completing task:" + t.getName());
			activitiContext.getTaskService().complete(t.getId());
		}
	}

	private void showPendingTasks() {
		System.out.println("Printing pending tasks...");
		List<Task> list = activitiContext.getTaskService().createTaskQuery().list();
		if (list.size() == 0) {
			System.out.println("Pending task list size is zero.");
		}
		for (Task t : list) {
			System.out.println("pending task:" + t.getId() + ":" + t.getName());
		}
	}

}