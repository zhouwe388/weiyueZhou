package mie.example;

import java.sql.Connection;
import java.sql.Statement;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import edu.toronto.dbservice.config.MIE354DBHelper;
import edu.toronto.dbservice.types.Person;

public class Lab5_2MultiInstanceServiceTask implements JavaDelegate {

	Connection dbCon = null;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		dbCon = MIE354DBHelper.getDBConnection();
		
		Person currentPerson = (Person) execution.getVariable("currentInstance");

		int updatedValue = (int) (currentPerson.salary * 1.5);

		Statement statement;
		statement = dbCon.createStatement();
		statement.execute("INSERT INTO OUTPUTTABLE VALUES ('" + currentPerson.name + "', " + updatedValue
				+ ")");

		statement.close();
		dbCon.close();
	}

}
