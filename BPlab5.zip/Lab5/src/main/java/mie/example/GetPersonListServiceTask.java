package mie.example;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import junit.framework.Assert;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import edu.toronto.dbservice.exceptions.SQLExceptionHandler;
import edu.toronto.dbservice.config.MIE354DBHelper;
import edu.toronto.dbservice.types.Person;

public class GetPersonListServiceTask implements JavaDelegate {

	Connection dbCon = null;

	public GetPersonListServiceTask() {
		dbCon = MIE354DBHelper.getDBConnection();
	}

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Statement statement;
		ResultSet resultSet = null;
		ArrayList<Person> personList = new ArrayList<Person>();
		String num_row = (String) execution.getVariable("num_rows");
		Integer num = Integer.parseInt(num_row);
		Integer i = 1 ;
		statement = dbCon.createStatement();
		// search for the person's name based on what was entered on the form
		resultSet = statement.executeQuery("SELECT * FROM people ORDER BY name");
		while (resultSet.next() && i <= num ) {
			String pName = resultSet.getString("name");
			int pSalary = resultSet.getInt("salary");
			Person p = new Person(pName, pSalary);
			personList.add(p);
			i++; 
		}

		resultSet.close();
		statement.close();

		dbCon.close();

		execution.setVariable("personList", personList);

	}

}
