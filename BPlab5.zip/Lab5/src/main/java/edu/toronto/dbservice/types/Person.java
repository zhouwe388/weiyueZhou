package edu.toronto.dbservice.types;

import java.io.Serializable;

public class Person implements Serializable {
	public String name;
	public int salary;
	public int newsalary;
	
	public Person(String n, int v) {
		this.name = n;
		this.salary = v;
	}
}
